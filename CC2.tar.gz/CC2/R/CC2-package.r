#' CC2.
#'
#' @name CC2
#' @docType package
NULL
