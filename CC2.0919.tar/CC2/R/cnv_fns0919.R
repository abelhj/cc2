

#The MIT License (MIT)

#Copyright (c) 2014 Haley Abel

#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:

#The above copyright notice and this permission notice shall be included in
#all copies or substantial portions of the Software.

#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#THE SOFTWARE.



combine_cov<-function(sample.infile=NULL, cov.file=NULL, cov.comb, last.autosome) {

  if(!is.null(sample.infile)) {
    if(!is.null(cov.file)) {
      print("Error:  Both sample batch file and and individual sample have been input.");
      quit();
    }
    sample.info=read.table(sample.infile, stringsAsFactors=FALSE);
    for(i in 1:nrow(sample.info)) {
      name=make.names(basename(sample.info[i,1]));
      dd=setNames(read.table(sample.info[i,1]), c("chrstr", "start", "stop", name, "zz", "target.len", "zz1"));
      dd=dd[!duplicated(dd[, c("chrstr", "start", "stop")]),];
      if(i==1) {
        covs=dd[, c("chrstr", "start", "stop", "target.len", name)];
      } else {
        covs=merge(covs, dd[, c("chrstr", "start", "stop", "target.len", name)], by=c("chrstr", "start", "stop", "target.len"), sort=FALSE);
      }
    }
  } else if (!is.null(cov.file)) {
    name=make.names(basename(cov.file));
    dd=setNames(read.table(cov.file), c("chrstr", "start", "stop", name, "zz", "target.len", "zz1"));
    dd=dd[!duplicated(dd[, c("chrstr", "start", "stop")]),];
    covs=dd[, c("chrstr", "start", "stop", "target.len", name)];
  } else {
    print("Error: missing input file");
    quit();
  }
  dd=NULL;
 
  num=chr.to.numeric(covs[, "chrstr"], last.autosome);
  covs=cbind(chr=num, covs);
  covs=covs[order(covs$chr, covs$start),];                          #re-sort after merge
  save(covs, file=cov.comb);
}


mask_low_coverage<-function(ctlmedfile, combfile, min_cov, last.autosome, read.len=100, infocols) {

  load(combfile);
  comb=covs;
  load(ctlmedfile);
  ctlmed=med;
  merged=merge(ctlmed, comb, by=infocols, sort=FALSE);
  merged=merged[merged$med*read.len/merged$target.len>min_cov ,];					
  merged=merged[order(merged$chr, merged$start),];
  covs=merged;
  save(covs, file=paste(combfile, ".low_cov_flt.RData", sep=""));
}


select.normals.get.med<-function(combfile, ctlcombfile, afdata=NULL, min.corr, min.normals, min.cov, last.autosome, medfile, read.len=100, infocols) {

  big.epsilon=2;
	
  load(combfile);
  casecov=covs;
  case=colnames(casecov)[6];
  
  load(ctlcombfile);
  ctlcov=covs;
  rm(covs);
  ctlnames=colnames(ctlcov)[6:ncol(ctlcov)];
	
  if(!is.null(afdata)) {	
	print(afdata);							#calculate correlation for targets with mean vaf in (0.40, 0.6)
    load(afdata);
	  afd=af.list[[1]][af.list[[1]]$GT=="0/1",];
	  ag=setNames(aggregate(maxaf~chr+start+stop, data=afd, FUN="mean"), c("chr", "start", "stop", "meanaf"));
	  ag1=setNames(aggregate(maxaf~chr+start+stop, data=afd, FUN="length"), c("chr", "start", "stop", "ct"));
	  ag=merge(ag, ag1);
	  ag=merge( ag, casecov);
	  ag=ag[ ag$meanaf<0.6 ,]; 
  } else {													#correlation for all targets
	  ag=casecov;
  }
  ag=merge(ag, ctlcov);
  ag=ag[ag$chr<=last.autosome,];
  corrmat=cor(ag[, case], ag[, ctlnames, drop=FALSE]);
  keepctl=colnames(corrmat[1,corrmat[1,]>min.corr, drop=FALSE]);
  if(length(keepctl)<min.normals) {
    print("Error:  Low correlation between case and control coverage profiles.  Try reducing min.correlation or min.normals.");
	  print(corrmat);
	  stop();
  }
  ag=casecov=NULL;
  ctlcov=ctlcov[, c(infocols, keepctl)]; 
  save(ctlcov, file=ctlcombfile);
	
  counts=ctlcov[, keepctl, drop=FALSE];
  dd=ctlcov[, infocols];
  total=apply(counts, FUN=sum, MARGIN=2);
  geomean=exp(mean(log(total)));
  for(i in 1:ncol(counts)) {
	  counts[,i]=counts[,i]/total[i]*geomean;													#normalize each sample by geometric mean
  }
  med=apply(counts, FUN=median, MARGIN=1);
  min=apply(counts, 1, FUN=min);
  max=apply(counts,1, FUN=max);
  min=log2((min+big.epsilon)/(med+big.epsilon));
  max=log2((max+big.epsilon)/(med+big.epsilon));
  med=cbind(dd, med, min, max);
  rm(dd);
  save(med, file=medfile);
  
  med=med[med$med*read.len/med$target.len>min.cov,];							#masks low coverage here
  save(med, file=paste(medfile, ".low_cov_flt.RData", sep=""));
  
}

chr.to.numeric<-function(chrstr, last.autosome) {
  num=as.character(chrstr);
  if(grepl("chr", num[1])) {  
    num=substring(num, 4);
  }
  num=as.character(num);
  num[num=="X"]<-last.autosome+1;
  num[num=="Y"]<-last.autosome+2;
  num[num=="MT"]<-last.autosome+3;
  return(as.numeric(num));
}


gc.correct.normalize<-function(combfile, medfile, normfile, frac.normal, last.autosome, afdata=NULL, fasta=NULL, bedfile=NULL, vaf.norm, infocols) {

  epsilon=0.25;
  
  if(is.null(fasta) || is.null(bedfile)) {
    print("Error:  missing reference.fa or target bedfile");
    quit();
  }
  gc=read.table(pipe(paste("nucBed -fi ", fasta, " -bed ", bedfile, sep="")), header=TRUE, comment.char="", stringsAsFactors=FALSE);
  gc=setNames(gc[, c(1:3,grep("gc", colnames(gc)))], c("chr", "start", "stop", "pct_gc"));
  gc=gc[!duplicated(gc[, c("chr", "start", "stop")]),];
  
  load(combfile);
  dd=covs;
  auto=(dd$chr<=last.autosome);
  load(medfile);
  med=med[, c(infocols, "med")];
  colnames(med)[6]="ctl.med";
  data=as.data.frame(merge(dd, med, by=infocols));
  data=data[order(data$chr, data$start),];
  
  case=colnames(data)[9];
  data=data[, c(case, "ctl.med"), drop=F];
  Mtest=log2(data+epsilon);  				#add small constant to avoid taking log(0), etc
  
  Mnorm=dd[, infocols];
  
  gc=as.data.frame(merge(Mnorm, gc), by=c("chr", "start", "stop"));
  gc=gc[order(gc$chr, gc$start),];
  log.ratio=Mtest[, case]-Mtest[, "ctl.med"];
  ls=loess(log.ratio[auto]~gc[auto,]$pct_gc);
  pred=predict(ls, gc$pct_gc);
  log.ratio=log.ratio-pred;
  
  if(vaf.norm==TRUE) {
    load(afdata);
    afd=af.list[[1]][af.list[[1]]$GT=="0/1",];
    ag=setNames(aggregate(maxaf~chr+start+stop, data=afd, FUN="mean"), c("chr", "start", "stop", "meanaf"));
    ag1=setNames(aggregate(maxaf~chr+start+stop, data=afd, FUN="length"), c("chr", "start", "stop", "ct"));
    ag=merge(ag, ag1);
    ag=merge(cbind(Mnorm, log.ratio), ag);
    ag=ag[ag$ct>1 & ag$meanaf<0.6 & ag$chr<=last.autosome,];	#recenter based on median ration in regions without LOH
    log.ratio=log.ratio-median(ag$log.ratio);
  } else {
    
    M1=cbind(case=Mtest[, "ctl.med"]+log.ratio, Mtest[,"ctl.med"]);
    M1.auto=M1[auto,];		                		#normalize each individual case against control median
    total=nrow(M1.auto);							#adapted from GRSN to find rank-invariant set
    
    count=floor(frac.normal*sum(auto));
    idx<-1:total;   subSet<-1:total;
    discardNumber <- (total - count) / 10
    while (TRUE)	{
      total <- floor(max(total - discardNumber, count))
      M2 <- apply(M1.auto[idx, ], 2, rank)
      V2 <- apply(M2, 1, var)
      subSet <- order(V2, decreasing=FALSE)[1:total]     
      idx <- idx[subSet]
      if (total == count) break
    }
    
    ls=loess(M1.auto[idx, "case"]~M1.auto[idx, 2]);
    pred=predict(ls, M1[, 2]);
    pred[is.na(pred)]<-M1[is.na(pred),2];
    log.ratio=M1[,1]-pred;
  }
  
  Mnorm=cbind(Mnorm, log.ratio);
  colnames(Mnorm)[6]=case;
  save(Mnorm, file=normfile);
  #write.table(Mnorm, file=normfile, quote=F, row.names=F, col.names=T, sep=",");
}

  
annotate.with.genes<-function(norm.cov.file, target.bedfile, annot.bedfile) {
  
  load(norm.cov.file);
  ncov=Mnorm;
  if(!is.null(annot.bedfile)){
    key=read.table(pipe(paste( "intersectBed -wa -u -a ", annot.bedfile, " -b ", target.bedfile, " | closestBed -a ", target.bedfile, " -b stdin -t first ", sep="")));  
	key=key[!duplicated(key[, 1:3]),]
    key=setNames(key[, c(1:3,7)], c("chrstr", "start", "stop", "gene"));
    ncov=merge(ncov, key, by=c("chrstr", "start", "stop"), all.x=TRUE, sort=FALSE);
  } else {
    ncov=cbind(ncov, gene=ncov$chrstr);
  }
  ncov=ncov[order(ncov$chr, ncov$start),];
  save(ncov, file=norm.cov.file);
}

merge.score.call<-function(depthlist, aflist, final.list, j, p.cov.cutoff, p.af.cutoff, af.threshold=0.58, coverage.min.ratio=0.75, coverage.max.ratio=1.25, maxhet=0.98) {
  
  load(depthlist);
  afdata=NULL;
  ncontrols=5;
  depth=depth.list[[j]];
  if(!is.null(aflist)) {
    load(aflist);
    afdata=af.list[[j]];
  }
  load(final.list);

  if(!is.null(afdata)) {

    aggregate(maxaf~chr+start+stop, data=afdata, FUN=function(x) c(mn =sum(x[x<maxhet]), n=length(x[x<maxhet]), maxaf=max(x), minaf=min(x))) ->ag
    mat=matrix(lapply(ag[,4], "[", 1), ncol=4, byrow=FALSE)
    ag=setNames(as.data.frame(cbind(ag[,-4], mat)), c("chr", "start", "stop", "sum", "ct", "maxmaf", "minmaf"));
    for(col in c("sum", "ct", "maxmaf", "minmaf")) {
      ag[, col]=unlist(ag[,col]);
    }
    
    mm=merge(depth, ag, by=c("chr", "start", "stop"), all.x=TRUE)
    ag2=setNames(aggregate(ct~segno, data=mm, FUN=sum, na.rm=TRUE), c("segno", "seghetct"));
    ag3=setNames(aggregate(sum~segno, data=mm, FUN=sum, na.rm=TRUE), c("segno", "mu"));
    ag3=merge(ag2, ag3, by="segno")
    ag3[, "mu"]=ag3[, "mu"]/ag3[, "seghetct"]
    mm1=merge(mm, ag3, by="segno", all.x=TRUE);
    mm1=mm1[, !(colnames(mm1) %in% c("sum", "ct"))]
    mm1=cbind(mm1, p.af.t=rep(NA, nrow(mm1)));
    mm1[is.na(mm1$seghetct), "seghetct"]<-0;
    mm1=mm1[, c(colnames(depth),  "seghetct", "mu", "p.af.t", "minmaf", "maxmaf")];
  } else {
    mm1=cbind(depth, maxmaf=rep(NA, nrow(depth)), minmaf=rep(NA, nrow(depth)), seghetct=rep(NA, nrow(depth)), mu=rep(NA, nrow(depth)), p.af.t=rep(NA, nrow(depth)));
  }		   
  case=colnames(mm1)[6];
  mm1=mm1[, c("chr", "chrstr", "start", "stop",  "target.len", case, "med", "min", "max", "gene", "segno", "seglogratio", "seghetct", "mu", "p.af.t", "minmaf", "maxmaf")]
  mm1=mm1[order(mm1$chr, mm1$start),];

  final=mm1;  mm1=NULL;
  final=cbind(final, p.cov.np=rep(0, nrow(final)), p.cov.t=rep(0, nrow(final)), p.combined=rep(0, nrow(final)), cn=rep(0, nrow(final)), finalcn=rep(0, nrow(final)));

  for(seg in unique(final$segno)) {
        
    dd1=final[final$segno==seg,];
	  log2ratio=dd1[,case];
	  if(dd1$seglogratio[1]>log2(coverage.max.ratio)) {
	    ct1=sum(log2ratio>dd1$max);
	    p.cov.np=pbinom(nrow(dd1)-ct1, size=nrow(dd1), prob=1/(1+ncontrols));
      p.cov.t=safe.t.test(log2ratio, alternative="greater");          
	  } else if (dd1$seglogratio[1]<log2(coverage.min.ratio)){
	    ct1=sum(log2ratio<dd1$min);
	    p.cov.np=pbinom(nrow(dd1)-ct1, size=nrow(dd1), prob=1/(1+ncontrols));
      p.cov.t=safe.t.test(log2ratio, alternative="less");
	  } else {
	    p.cov.np=1;
	    p.cov.t=1;
  	}
  	p.af.t=dd1$p.af.t[1];
    if(!is.na(p.cov.np) && !is.na(p.cov.t)) {
	    fishsum=-2*(log(p.cov.t)+log(p.cov.np));
	    p.combined=pchisq(fishsum, df=4, lower.tail=FALSE);
  	} else {
	    p.combined=min(p.cov.np, p.cov.t, na.rm=TRUE);
  	}
	  final[final$segno==seg, ]$p.cov.np=p.cov.np;
	  final[final$segno==seg, ]$p.cov.t=p.cov.t;
  	final[final$segno==seg, ]$p.combined=p.combined;

  	paf=final[final$segno==seg, "p.af.t"][1];
  	pcov=final[final$segno==seg, "p.cov.t"][1];
  	mu=final[final$segno==seg, "mu"][1];
    pcomb=final[final$segno==seg, "p.combined"][1];
    seglogratio=final[final$segno==seg,  "seglogratio"][1]
	  cn=cn1=2;

    if(!is.na(pcov) && pcov<p.cov.cutoff) {
	    cn=2*2^seglogratio;
	    if(is.na(mu) ||  mu>af.threshold) {
		    cn1=2*2^seglogratio;
	    }
    }
    final[final$segno==seg, "cn"]<-cn;
    final[final$segno==seg, "finalcn"]<-cn1;
  }
  depth.list.final[[j]]<-final;
  save(depth.list.final, file=final.list);
}


plot.cn1106<-function(dd, restrict=NULL, thin=NULL, title) {

  layout(c(1,2), widths=c(1), height=c(1,1));
  dd=dd[order(dd$chr, dd$start),];
  if(!is.null(thin)) {
    ss=seq(from=1, to=nrow(dd), by=thin);
    dd=dd[ss,];
  }
  gg=dd$genenum;
  gg1=c(0, gg[-length(gg)]);
  cc=dd$chr;
  cc1=c(0, cc[-length(cc)])
  dd=cbind(dd, diff=gg1-gg, index=c(1:nrow(dd)), chrdiff=cc1-cc);
  vlines=dd[dd$diff!=0, "index"]
  darklines=dd[dd$chrdiff<0, "index"];
  chrlabs=dd[dd$chrdiff!=0, "chr"];
  labs=dd[dd$diff!=0, "gene"];
  dd=cbind(dd, log2ratio=dd[,6]);
  dd=cbind(dd, col=ifelse(dd$chr %% 2 ==0, "black", "grey"));
 
  dd$col=as.character(dd$col);
  par(mar=c(0.5,3,1,1),oma=c(0.5,1,0.5,1));
  if(is.null(restrict)) {
    plot(dd$log2ratio, axes=F, main=title, ylim=c((min(min(dd$log2ratio), log2(0.25)))-0.5, (max(max(dd$log2ratio), log2(4)))+0.5), cex=0.5, col="black"); #col=dd$col);
  } else {
	  dd$log2ratio=pmin(dd$log2ratio, log2(restrict[2]));       #clip log ratio
    dd$log2ratio=pmax(dd$log2ratio, log2(restrict[1]));
    plot(dd$log2ratio, axes=FALSE, main=title, ylim=c( log2(restrict[1]),  log2(restrict[2])), cex=0.5, col="black");		
  }
  axis(2, labels=NA, tck=-0.02, cex.axis=0.75);
  axis(2, lwd=0, line=-0.4, las=1, cex.axis=0.75);
  box();

  mtext(side=2, "log2ratio", line=2);
  dd$cn=dd$cn/2;
  dd$finalcn=dd$finalcn/2;
  if(!is.null(restrict)) {
    dd$cn=pmin(dd$cn, restrict[2]);
    dd$cn=pmax(dd$cn, restrict[1]);
    dd$finalcn=pmin(dd$finalcn, restrict[2]);
    dd$finalcn=pmax(dd$finalcn, restrict[1]);
  }
  points(log2(dd$cn), col="orange", cex=0.5);
  points(log2(dd$finalcn), col="red", cex=0.5);
  

  for(j in darklines) {abline(v=j, col="darkgrey")}
  ytext=c(max(max(dd$log2ratio), log2(4) ));
  if(!is.null(restrict)) {
    ytext=c( log2(restrict[2]-1) );
  }
  xtext=0.5*(darklines+c(darklines[-1], nrow(dd)));
  text(xtext, ytext, labels=paste("chr",chrlabs), srt=90);
  abline(h=log2(0.75), col="green");
  abline(h=log2(1.25), col="green");
  abline(h=log2(0.5), col="orange");
  abline(h=log2(1.5), col="orange");

  hetct=pmin(dd$seghetct, 5);
	par(mar=c(3,3,0,1));
  plot(dd$maxmaf, axes=F, col="grey", ylim=c(0,1), cex=0.3); 
  points(dd$minmaf, col="grey", cex=0.3);
  points(dd$mu, col=(hetct+1), cex=0.5);
 
  abline(h=0.5, col="green");
  abline(h=0.58, col="green");
  pos=0.5*(vlines+c(vlines[-1], nrow(dd)));
  alt=c(TRUE, FALSE);
  alt1=c(FALSE, TRUE);
  axis(1, at=pos[alt], labels=labs[alt], las=2, cex.axis=0.5, tck=-0.005, mgp=c(3,0.3, 0));
  if(length(labs)>1) {
    axis(1, at=pos[alt1], labels=labs[alt1], las=2, cex.axis=0.5, tck=-0.005, mgp=c(3,2.2,0));
  }
	
  # axis(1, at=0.5*(vlines+c(vlines[-1], nrow(dd))),labels=labs,  las=2, cex.axis=0.5, tck=-0.005)
  axis(2, labels=NA, tck=-0.02, cex.axis=0.75);
  axis(2, lwd=0, line=-0.4, las=1, cex.axis=0.75);
  box();
  mtext(side=2, "maxaf", line=2);
  for(j in darklines) {abline(v=j, col="darkgrey")}
  legend("bottomleft", legend=c("0", "1", "2","3", "4", "5+"), col=c(1:6), pch=15);
}



safe.t.test<-function(...) {
    obj=try(t.test(...), silent=TRUE);
    if (is(obj, "try-error")) return(NA) else return(obj$p.value);
}

segment_norm<-function( norm.cov.file, range.file, outfile, minwid=3, segalpha=0.01, sdundo=2, infocols) {
  
  depth.list=vector("list", 1);
  load(norm.cov.file);
  load(range.file);
  rg=med;
  ncov=merge(ncov, rg, by=infocols, sort=FALSE);
  ncov=ncov[order(ncov$chr, ncov$start),];
  case=colnames(ncov)[6];
  
  CNAobj=DNAcopy::CNA(ncov[, case, drop=FALSE], ncov$chr, 0.5*(ncov$start+ncov$stop));
  smCNAobj=DNAcopy::smooth.CNA(CNAobj);
  seg=DNAcopy::segment(smCNAobj, undo.splits="sdundo", p.method="perm", alpha=segalpha, min.width=minwid, undo.SD=sdundo);
  
  out=seg$out;
  out=out[out$ID==paste("Sample.",1, sep=""),];
    
  test=ncov[, c(infocols, case, "med", "min", "max", "gene")];
  test=cbind(test, segno=rep(0,nrow(test)), seglogratio=rep(0,nrow(test)));
  for(i in 1:nrow(out)) {
    sub=(test$chr==out$chrom[i])& ((test$start>=out$loc.start[i] & test$start<=out$loc.end[i])|(test$stop>=out$loc.start[i] & test$stop<=out$loc.end[i])| (test$start<out$loc.start[i] & test$stop>=out$loc.start[i]));
    nr=sum(sub);
    test[sub, c("segno", "seglogratio")]<-cbind(rep(i, nr), rep(out$seg.mean[i], nr));
  }
  depth.list[[1]]<-test;
  save(depth.list, file=outfile);
}

get.key.val<-function(vv, rx) {
  vv1=unlist(strsplit(vv, ";"));
  regexpr(rx, vv1 )->mm;
  return(regmatches(vv1, mm));
}

get.val<-function(vv, rx) {
  str=get.key.val(vv, rx);
  val=unlist(strsplit(str, "="))[2];
  return(val);
}

get.format.val<-function(format.data, rx) {
  fd=unlist(strsplit(format.data, split="_"));
  format1=unlist(strsplit(fd[1], ":"));
  data1=unlist(strsplit(fd[2], ":"));
  found=grepl(rx, format1);
  return(data1[grepl(rx, format1)]); 
}

dp4.to.af<-function(dp4) {
  dp4=as.numeric(unlist(strsplit(dp4, ",")));
  return((sum(dp4[1:2])+0.5)/(sum(dp4)+0.5));
}

ad.to.af<-function(ad) {
  ad=as.numeric(unlist(strsplit(ad, ",")));
  return((ad[1]+0.5)/(sum(ad)+0.5));
}


af.to.exons<-function(exon.target, snp.wingspan, last.autosome, vcf, min.cov=20, outfile, tempdir, vcftype) {
  
  af.list=NULL;
  nts=c("A", "C", "G", "T");
  var.bedfile=NULL; 
  if(snp.wingspan>0) {
    bed=read.table(exon.target, stringsAsFactors=FALSE);
    bed[,2]=pmax(1, bed[,2]-snp.wingspan);
    bed[,3]=bed[,3]+snp.wingspan;
    var.bedfile=paste(tempdir, "/", basename(exon.target), ".tmp.bed", sep="");
    write.table(bed, file=var.bedfile, quote=FALSE, row.names=FALSE, col.names=FALSE, sep="\t");
  } else {
    var.bedfile=exon.target;
  }

  af.list<-vector("list", 1);
  if(vcftype=="VCF") {
    
    vafs=read.table(pipe(paste( "intersectBed -wa -u -a ", vcf, " -b ", var.bedfile, " | closestBed -a stdin -b ", exon.target, " -t first", sep="")), stringsAsFactors=FALSE);
    vafs=setNames(vafs[, c(1:2,4:5,8:10,12:13)], c("chrstr", "pos", "ref", "alt","info", "format", "vals", "start", "stop"));
    depth=maf=GT=NULL;
    if(grepl("DP=", vafs[1,"info"])) {
      depth=as.numeric(unlist(lapply(vafs$info, "get.val", "^DP=\\d+")));
    } else if (grepl("DP", vafs[1, "format"])) {
      depth=as.numeric(unlist(lapply(paste(vafs$format, vafs$vals, sep="_"), "get.format.val", "DP")));
    } else {
      print("Error: unexpected vcf format, no depth found");
      exit(10);
    }
    vafs=cbind(vafs, depth);
    vafs=vafs[vafs$ref %in% nts & vafs$alt %in% nts & vafs$depth>min.cov,];
    if(grepl("DP4", vafs[1, "info"])) {
      dp4=unlist(lapply(vafs$info, "get.val", "^DP4=[0-9]+,[0-9]+,[0-9]+,[0-9]+"));
      maf=unlist(lapply(dp4, "dp4.to.af"));
    } else if(grepl("AD", vafs[1,"format"])) {
      ad=unlist(lapply(paste(vafs$format, vafs$vals, sep="_"), "get.format.val", "AD"));
      maf=unlist(lapply(ad, "ad.to.af"));
    } else {
      print("Error: unexpected vcf format, no DP4 or AD field found.");
    }
    if(grepl("GT", vafs[1,"format"])) {
      GT=unlist(lapply(paste(vafs$format, vafs$vals, sep="_"), "get.format.val", "GT"));
    } else {
      GT=ifelse((maf>0.97 | maf<0.03), "1/1", "0/1");
    }
    
  } else if(vcftype=="VARSCAN") {
    
    print(paste(  "  awk ' { print $1\"\t\"$2-1\"\t\"$2\"\t\"$3\"\t\"$4\"\t\"$5\"\t\"$6\"\t\"$7\"\t\"$8\"\t\"$9\"\t\"$10}' ", vcf, " | intersectBed -wa -u -a stdin  -b ", var.bedfile, " | closestBed -a stdin -b ", exon.target, " -t first ", sep=""));
    vafs=read.table(pipe(paste(  "  awk ' { print $1\"\t\"$2-1\"\t\"$2\"\t\"$3\"\t\"$4\"\t\"$5\"\t\"$6\"\t\"$7\"\t\"$8\"\t\"$9\"\t\"$10}' ", vcf, " | intersectBed -wa -u -a stdin  -b ", var.bedfile, " | closestBed -a stdin -b ", exon.target, " -t first ", sep="")), stringsAsFactors=FALSE);
    vafs=setNames(vafs[, c(1, 3:5, 10,11,13,14)], c("chrstr", "pos", "ref", "alt", "nref", "nalt", "start", "stop"));
    vafs=cbind(vafs, depth=vafs$nref+vafs$nalt);
    vafs=vafs[vafs$ref %in% nts & vafs$alt %in% nts & vafs$depth>min.cov, c(1,2,5:9)];
    maf=(vafs$nalt+0.5)/(vafs$depth+0.5);
    GT=ifelse((maf>0.97 | maf<0.03), "1/1", "0/1");
    
  } else {
      print("Error must specify vcf type.");
    exit(10);
  }
  vafs=data.frame(chrstr=vafs$chrstr, pos=vafs$pos, depth=vafs$depth, GT, maf, start=vafs$start, stop=vafs$stop);
  chr=chr.to.numeric(vafs[, "chrstr"], last.autosome);
  vafs=cbind(vafs, chr, maxaf=pmax(vafs$maf, 1-vafs$maf));
  vafs=vafs[vafs$depth*vafs$maxaf<(vafs$depth-3),];
  vafs=vafs[vafs$GT=="0/1" | vafs$GT=="1/1",];
  af.list[[1]]<-vafs;
  save(af.list, file=outfile)
  
}

merge_depth_af<-function( depthlist, aflist, outlist, p.cov.cutoff, p.af.cutoff, useaf, af.threshold=0.58, coverage.min.ratio=0.75, coverage.max.ratio=1.25) { 

  depth.list.final<- vector("list", 1);
  save(depth.list.final, file=outlist);

  if(useaf) {
    merge.score.call(depthlist, aflist, outlist, 1, p.cov.cutoff, p.af.cutoff, af.threshold=0.58, coverage.min.ratio=0.75, coverage.max.ratio=1.25, maxhet=0.98);
  } else {
    merge.score.call(depthlist, NULL, outlist, 1, p.cov.cutoff, p.af.cutoff, af.threshold=0.58, coverage.min.ratio=0.75, coverage.max.ratio=1.25, maxhet=0.98);
  }
}


plot_depth_af.1213<-function(target.bedfile, tempfile, plotfile, regstarts, regstops, restrict, thin=NULL, restrictbed=NULL, png=FALSE) {
  
    if(png && length(regstarts)==1) {
      jpeg(file=paste(plotfile, ".jpg", sep="") ,width=10.5, height=7.5, units="in", res=100);
    } else {
      pdf(file=paste(plotfile, ".pdf", sep="") ,width=10.5, height=7.5, paper="USr");
    }
    par(ask=F, oma=c(0,0,0,0));
  
    if(!is.null(restrictbed)) {
      #subspace=read.table(pipe(paste( "intersectBed -wa -u -a ",restrictbed, " -b ", target.bedfile, " | closestBed -a ", target.bedfile, " -b stdin -t first ", sep="")));  
	  subspace=read.table(pipe(paste( "intersectBed -wa -u -b ",restrictbed, " -a ", target.bedfile, sep="")));
      subspace=subspace[!duplicated(subspace[, 1:3]),];
    }

    load(tempfile);	#regstarts=c(1,4,7,10,14, 18);	#regstops=c(3,6,9,13, 17, 24);
  
    
      for( reg in 1:length(regstarts)) {
        dd=depth.list.final[[1]];
        if(!is.null(restrictbed)) {
          dd=dd[paste(dd$chrstr, dd$start, dd$stop) %in% paste(subspace[,1], subspace[,2], subspace[,3]),];
        }
        dd=dd[dd$chr>=regstarts[reg] & dd$chr<=regstops[reg],];
        dd=cbind(dd, genenum=rep(0, nrow(dd)));
        dd$genenum=as.numeric(as.factor(dd$gene));
        plot.cn1106(dd, restrict, thin, colnames(dd)[6]);
      }
    dev.off();
}

join.unique.genes<-function(vec) {
  vec=unique(vec);
  return(paste(vec, collapse="_"));
}

write_outfile<-function( outlist, outfile, sigoutfile, p.af.cutoff=0.05, p.cov.cutoff=0.05) {
  
  allresults=NULL;
  sigresults=NULL;
  load(outlist);
  name=colnames(depth.list.final[[1]])[6];
  dd=depth.list.final[[1]];
  results=cbind(sample=rep(name, nrow(dd)), dd[, c("chr", "chrstr", "start", "stop", "gene", "segno", "seglogratio",  "seghetct", "mu", "p.af.t", "p.cov.np", "p.cov.t", "p.combined", "cn", "finalcn")]);
  results$gene=as.character(results$gene);

  minag=aggregate(start~chr+chrstr+segno, data=results, FUN="min");
  maxag=aggregate(stop~chr+chrstr+segno, data=results, FUN="max");
  geneag=setNames(aggregate(gene~chr+chrstr+segno, data=results, FUN="unique"), c("chr", "chrstr", "segno", "genes"));
  geneag$genes=unlist(lapply(geneag$genes, paste, collapse="_"));
  ag=merge(maxag, minag);
  ag=merge(ag, geneag);
  results=results[, c("sample", "chr", "chrstr", "segno", "seglogratio", "seghetct", "mu", "p.af.t", "p.cov.np", "p.cov.t", "p.combined", "cn", "finalcn")]
  results=results[!duplicated(results),]
  results=merge(results, ag);
  results=results[, c("sample", "chr", "chrstr", "start", "stop", "segno", "seglogratio", "seghetct", "mu", "p.af.t", "p.cov.np", "p.cov.t", "p.combined", "cn", "finalcn", "genes")];
  results=results[order(results$chr, results$start),] 
  allresults=rbind(allresults, results);
  sigresults=rbind(sigresults, results[results[, "cn"]!=2,]);

  write.table(allresults, outfile, quote=FALSE, row.names=FALSE, col.names=TRUE, sep=",");
  write.table(sigresults, sigoutfile, quote=FALSE, row.names=FALSE, col.names=TRUE, sep=",");
}





    







	
	
