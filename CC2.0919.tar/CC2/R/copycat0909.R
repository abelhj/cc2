#!/usr/bin/Rscript --vanilla

#The MIT License (MIT)

#Copyright (c) 2014 Haley Abel

#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:

#The above copyright notice and this permission notice shall be included in
#all copies or substantial portions of the Software.

#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#THE SOFTWARE.

#' @title copycat2
#'
#' @description main cc2 function
#' 
#'
#' @param test_cov single case coverage file (in 7-column BEDTools output format, containing bait- or exon-level coverage)
#' @param test_vcf single case vcf file (accepts standard vcf and some varscan formatted files), optional but recommended
#' @param ctl_info file containg list of control coverage files (with absolute file paths)
#' @param use_af use allele frequency information
#' @param min_coverage minimum coverage in controls (else target excluded)
#' @param plot.only replot to adjust plotting parameters (must have saved temp files, i.e., clean.up=FALSE)
#' @param outdir output directory
#' @param target.bedfile bedfile used for coverage calculation (3 columns only)
#' @param annot.bedfile bedfile for gene annotation (4 columns) (optional)
#' @param snp.wingspan include SNVs this distance from targets in target.bedfile
#' @param plot.bedfile (optional) used to restrict the plot region (3 column)
#' @param outprefix prefix for output files (without path)
#' @param fa reference genome fasta file
#' @param plot.starts comma separated list of start chr for plots (e.g., to plot all chr on same page, starts=1, stops=22.  To plot one chr/page, starts=1,2,3...22, stops=1,2,3...22)
#' @param plot.stops see plot.starts
#' @param p.af.cutoff deprecated
#' @param p.cov.cutoff p-value threshold for calling a CNV based on coverage ratio
#' @param af.threshold upper bound of 'normal' MAF for heterozygotes absent LOH
#' @param png deprecated
#' @param coverage.min.ratio log2 ratio threshold to call deletion
#' @param coverage.max.ratio log2 ratio threshold to call amplication
#' @param minwid (passed to CBS)
#' @param segalpha (passed to CBS)
#' @param sdundo (passed to CBS)
#' @param restrict restict plot to range of coverage ratios (e.g., 0.125,6 ), outliers are truncated to min or max
#' @param last.autosome change for non-human
#' @param frac.normal expected fraction of targeted region that is copy neutral
#' @param thin.rate thinning rate for plots only
#' @param plot.id new plot label (for replotting)
#' @param vcftype format for variant file "VCF" or "VARSCAN"  (VARSCAN refers to older non-vcf format, for single sample)
#' @param min.var.cov min coverage at SNV position for inclusion (useful if using SNVs in shoulder region)
#' @param vafs_normalize normalize assuming targets without LOH are copy neutral (vs loess normalization on rank-invariant set)
#' @param min.normal.corr min correlation between case and control coverage (for choice of normals
#' @param min.num.normals min number of controls to pool  (if there are not enough controls with correlation>min.normal.corr cc2 with fail with an error message)
#' @param clean.up remove temp directories
#' @param read_len read length
#'
#' 
#' 
#' @export



copycat2<-function(test_cov, test_vcf, ctl_info, outdir, outprefix, target.bedfile, fa, vcftype, use_af=TRUE, min_coverage=20, plot.only=FALSE, annot.bedfile=NULL, snp.wingspan=0, plot.bedfile=NULL,  plot.starts=1, plot.stops=22, p.af.cutoff=1e-4, p.cov.cutoff=1e-4, af.threshold=0.58, png=FALSE, coverage.min.ratio=0.75, coverage.max.ratio=1.25, minwid=5, segalpha=0.01, sdundo=2, restrict="0.125,6", last.autosome=22, frac.normal=0.5, thin.rate=NULL, plot.id="", min.var.cov=20, vafs_normalize=TRUE, min.normal.corr=0.8, min.num.normals=3, clean.up=TRUE, read_len=100) {

print("ok");


if(vafs_normalize && !use_af) {
  print("Can't do VAF-based normalization with use_af=FALSE.");
  stop();
}

if(is.null(test_cov)) {
  print("test cov file both missing");
  stop();
}
if(is.null(ctl_info)) {
  print("ctl info file missing.")
  stop();
}
if(is.null(outdir)) {
  print("must specify outdir.");
  stop();
}
if(is.null(target.bedfile)) {
  print("target bedfile missing.");
  stop();
}
if(is.null(fa)) {
  print("fasta file missing.")
  stop();
}
plot.starts=as.numeric(unlist(strsplit(as.character(plot.starts), split=",")))
plot.stops=as.numeric(unlist(strsplit(as.character(plot.stops), split=",")))

if(!is.null(restrict)) {
  restrict=as.numeric(unlist(strsplit(as.character(restrict), split=",")));
  print(restrict);
}

tempdir="";
epsilon=0.25;
big.epsilon=2;
infocols=c("chr", "chrstr", "start", "stop", "target.len");
BEDTools="";


ctlcomb=ctlmedfile=combfile=combfile.flt=ctlmedfile.flt=ctlcombfile.flt=mrnfile=temp1=temp2=temp3=NULL;

dir.create(outdir);
tempdir=paste(outdir, "/temp_", outprefix, sep="");
dir.create(tempdir);


ctlcombfile=paste(tempdir, '/ctl_comb.RData', sep="");
ctlmedfile=paste(tempdir, '/ctl.med.RData', sep="");
combfile=paste(tempdir, '/comb.RData', sep="");
combfile.flt=paste(combfile, ".low_cov_flt.RData", sep="");
ctlmedfile.flt=paste(ctlmedfile, ".low_cov_flt.RData", sep="");
ctlcombfile.flt=paste(ctlcombfile, ".low_cov_flt.RData", sep="");
mrnfile=paste(tempdir, '/test.mrn.RData', sep="");


temp1=paste(tempdir, "/temp1.RData", sep="");
#temp2=paste(tempdir, "/temp2.RData", sep="");
temp3=paste(tempdir, "/temp3.RData", sep="");
 
  
print("combining case coverage");
combine_cov(NULL, cov.file=test_cov, cov.comb=combfile, last.autosome=last.autosome);

if(plot.only) {
  plot_depth_af.1213( target.bedfile, tempfile=temp3, plotfile=paste(outdir, "/cc.", outprefix, plot.id, sep=""), plot.starts, plot.stops, restrict=restrict, thin=thin.rate, restrictbed=plot.bedfile);
} else {
  print("combining control coverage");
  combine_cov(sample.infile=ctl_info, cov.comb=ctlcombfile, cov.file=NULL, last.autosome=last.autosome);
  if(use_af) {
    print("calculating vafs");
    temp2=paste(tempdir, "/temp2.RData", sep="");
    af.to.exons(exon.target=target.bedfile, snp.wingspan=snp.wingspan, last.autosome=last.autosome, vcf=test_vcf, min.cov=min.var.cov, outfile=temp2, tempdir=tempdir, vcftype=vcftype);
  } 
  print("choosing normals");
  select.normals.get.med(combfile, ctlcombfile, temp2, min.normal.corr, min.num.normals, min_coverage, last.autosome, ctlmedfile, read_len, infocols=infocols);
    
  print("masking low coverage regions");
  mask_low_coverage(ctlmedfile, combfile, min_coverage, last.autosome, read_len, infocols=infocols);
  
  print("gc correction and normalization");
  gc.correct.normalize(combfile.flt, ctlmedfile.flt, mrnfile, frac.normal, last.autosome, temp2, fa, target.bedfile, vafs_normalize, infocols=infocols);
  annotate.with.genes(mrnfile, target.bedfile, annot.bedfile);
  
  print("segmentation")
  segment_norm(mrnfile, ctlmedfile.flt, temp1, minwid=minwid, segalpha=segalpha, sdundo=sdundo, infocols=infocols);
  
  print("merging coverage data with vafs");
  merge_depth_af( temp1, temp2, temp3, p.cov.cutoff, p.af.cutoff, use_af, af.threshold, coverage.min.ratio, coverage.max.ratio); 
  print("plotting");
  plot_depth_af.1213(  target.bedfile, tempfile=temp3, plotfile=paste(outdir, "/cc.", outprefix, plot.id,  sep=""), plot.starts, plot.stops, restrict=restrict, thin=thin.rate, restrictbed=plot.bedfile, png);
  print("writing output file");
  write_outfile( temp3, outfile=paste(outdir, "/cc.results.", outprefix, ".csv", sep=""), sigoutfile=paste(outdir, "/cc.sig.results.", outprefix, ".csv", sep=""), p.af.cutoff, p.cov.cutoff);
  
  if(clean.up) {
    unlink(tempdir);
  }
}
}


